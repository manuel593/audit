# Mdotti Scripts
## Objetivo do zboox-installer.sh

O script `zboox-installer.sh` tem como objetivo automatizar a instalação e configuração do Zboox. Ele facilita o processo de instalação, garantindo que todas as dependências necessárias sejam instaladas e configuradas corretamente, permitindo que os usuários comecem a usar o Zboox rapidamente e sem complicações.

### Funcionalidades

- Instalação automática das dependências necessárias.
- Configuração inicial do ambiente.
- Verificação de compatibilidade do sistema.
- Criação de diretórios e arquivos de configuração padrão.

### Como usar

Para utilizar o script, siga os passos abaixo:

1. Clone o repositório do GitLab:
    ```sh
    git clone https://gitlab.sumetecnologia.com.br/mdotti/mdotti_scripts.git
    ```
2. Navegue até o diretório do script:
    ```sh
    cd mdotti_scripts
    ```
3. Dê permissão de execução ao script:
    ```sh
    chmod +x zboox-installer.sh
    ```
4. Execute o script:
    ```sh
    ./zboox-installer.sh
    ```

### Suporte

Se você encontrar problemas ou tiver dúvidas sobre o uso do script, por favor, abra uma solicitao para a SUME Tecnologia.

### Licença

Este projeto está licenciado para a MDOTTI.
